import React from "react";
import "./style.css";


export default function Footer() {
  return (
    <footer className="footer">
      <p>Integrantes: Pedro Maldini, Nicolas Etchepare, Octavio Guerra</p>
    </footer>
  );
}