import React from "react";

export default function NotFound() {
  return (
    <div>
      <h1>404 - Contenido Inexistente</h1>
      <p>La página que estás buscando no existe.</p>
    </div>
  );
}
